#include <stdio.h>
int main(){
    int chang=7,kuan=2;
    int mianji;
    int zhouchang;

    mianji=chang*kuan;
    zhouchang=(chang+kuan)*2;

    printf("周长是%d\n",zhouchang);
    printf("面积是%d\n",mianji);

    return 0;
}
