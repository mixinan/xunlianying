#include <stdio.h>
int main(){
    int chang=6;
    int kuan=4;
    printf("周长是%d\n",(chang+kuan)*2);
    printf("面积是%d\n",chang*kuan);

    return 0;
}
