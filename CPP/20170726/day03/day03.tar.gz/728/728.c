#include <stdio.h>
//这是主函数，程序的入口
int main(){
    
    //printf("请输入a和b的值：\n");
    //scanf("%d%d",&a,&b);
    printf("5>6 %d\n",5>6);
    printf("5<6 %d\n",5<6);
    printf("5==6 %d\n",5==6);
    printf("5!=6 %d\n",5!=6);
    printf("5?1:0 %d\n",5?1:0);
    return 0;
}
