#include <stdio.h>
int main(){
    int n;
    int m;
    printf("请输入2个整数：\n");
    scanf("%d%d",&n,&m);
    printf("m=%d,n=%d\n",m,n);

    return 0;
}
