#include <stdio.h>
int main(){
    printf("5/2=%d\n",5/2);
    printf("5%%2=%d\n",5%2);
    printf("\\\n");
    printf("\"\n");
    return 0;
}
