#include <stdio.h>
int main(){
    int r=5;
    printf("周长=%g\n",2*3.14*r);
    printf("面积=%g\n",3.14*r*r);
    return 0;
}
