#include <stdio.h>
/*
 作者：
 时间：
 功能：
  */
int main(){ //test
   // 我是主函数
  return 0;//kdkk
}
